<?php

namespace main;

class Page {

    function get_show() {
        \Standard::getShow();
    }
}

?>
