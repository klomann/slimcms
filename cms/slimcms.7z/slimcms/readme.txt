cms based on fat free farmework
demo: http://blog.tapez.eu/cms
demo login:
name: admin
pw: admin
download: http://blog.tapez.eu/download/slimcms.7z